# drone detection > 2023-06-23 6:16pm
https://universe.roboflow.com/project-tiamr/drone-detection-04s7b

Provided by a Roboflow user
License: CC BY 4.0

